package com.example.CIDI_Test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CidiTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
