package com.example.CIDI_Test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CidiTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CidiTestApplication.class, args);
	}

}
